
Step1:-First open the command prompt

Step2:-Using command prompt, reach upto your folder Location.

Step3:-Type "javac Assignment.java" and press Enter key.

Step4:-Enter "java Assignment" and press Enter key.

Step5:-Enter Path of your file(Copy and Paste the File Path) and than press Enter key.

Step6:-Enter the Format Like TitleCase, UpperCase or LowerCase.

Then you will see the output.